import sqlite3
import xml.dom.minidom as minidom

conn = sqlite3.connect('Literature.db')
cursor = conn.cursor()

# Create authors XML
authors_xml = minidom.Document()
authors_root = authors_xml.createElement('authors_xml')
authors_xml.appendChild(authors_root)
authors = cursor.execute('SELECT * FROM Authors').fetchall()
for author in authors:
    author_elem = authors_xml.createElement('author')
    author_elem.setAttribute('id', str(author[0]))
    author_elem.setAttribute('name', str(author[1]))
    authors_root.appendChild(author_elem)

# Save authors XML to file
with open('authors.xml', 'w') as file:
    file.write(authors_xml.toprettyxml())

# Create books XML
books_xml = minidom.Document()
books_root = books_xml.createElement('books_xml')
books_xml.appendChild(books_root)
books = cursor.execute('SELECT * FROM Books').fetchall()
for book in books:
    book_elem = books_xml.createElement('book')
    book_elem.setAttribute('id', str(book[0]))
    book_elem.setAttribute('title', str(book[1]))
    book_elem.setAttribute('year', str(book[2]))
    book_elem.setAttribute('author_id', str(book[3]))
    book_elem.setAttribute('genre_id', str(book[4]))
    books_root.appendChild(book_elem)

# Save books XML to file
with open('books.xml', 'w') as file:
    file.write(books_xml.toprettyxml())

# Create genres XML
genres_xml = minidom.Document()
genres_root = genres_xml.createElement('genres_xml')
genres_xml.appendChild(genres_root)
genres = cursor.execute('SELECT * FROM Genres').fetchall()
for genre in genres:
    genre_elem = genres_xml.createElement('genre')
    genre_elem.setAttribute('id', str(genre[0]))
    genre_elem.setAttribute('name', str(genre[1]))
    genres_root.appendChild(genre_elem)

# Save genres XML to file
with open('genres.xml', 'w') as file:
    file.write(genres_xml.toprettyxml())

conn.close()
