import sqlite3
import xml.dom.minidom as minidom

conn = sqlite3.connect('Literature.db')
cursor = conn.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS Books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    year INTEGER,
    author_id INTEGER,
    genre_id INTEGER
    ); 
""")
conn.commit()

cursor.execute("""CREATE TABLE IF NOT EXISTS Authors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
    ); 
""")
conn.commit()

cursor.execute("""CREATE TABLE IF NOT EXISTS Genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
    ); 
""")
conn.commit()

dom = minidom.parse('my_xml.xml')
root = dom.documentElement

authors = root.getElementsByTagName('author')
books = root.getElementsByTagName('book')
genres = root.getElementsByTagName('genre')

for author in authors:
    name = author.getAttribute('name')
    cursor.execute("""INSERT INTO Authors(name) VALUES (?);""", (name,))

for book in books:
    title = book.getAttribute('title')
    year = int(book.getAttribute('year'))
    author_id = int(book.getAttribute('author_id'))
    genre_id = int(book.getAttribute('genre_id'))
    cursor.execute("""INSERT INTO Books(title, year, author_id, genre_id) VALUES (?, ?, ?, ?);""",
                   (title, year, author_id, genre_id))

for genre in genres:
    name = genre.getAttribute('name')
    cursor.execute("""INSERT INTO Genres(name) VALUES (?);""",
                   (name,))

conn.commit()
conn.close()
