from django.urls import path
from . import views
from django.urls import include, re_path

urlpatterns = [
    re_path(r'^$', views.index, name='index'),
    re_path(r'^authors/$', views.AuthorsListView.as_view(), name='authors'),
    re_path(r'^authors/(?P<pk>\d+)$', views.AuthorsDetailView.as_view(), name='authors-detail'),
    re_path(r'^authors/create/$', views.AuthorsCreate.as_view(), name='authors_create'),
    re_path(r'^authors/(?P<pk>\d+)/update/$', views.AuthorsUpdate.as_view(), name='authors_update'),
    re_path(r'^authors/(?P<pk>\d+)/delete/$', views.AuthorsDelete.as_view(), name='authors_delete'),
    re_path(r'^genres/$', views.GenresListView.as_view(), name='genres'),
    re_path(r'^genres/(?P<pk>\d+)$', views.GenresDetailView.as_view(), name='genres-detail'),
    re_path(r'^genres/create/$', views.GenresCreate.as_view(), name='genres_create'),
    re_path(r'^genres/(?P<pk>\d+)/update/$', views.GenresUpdate.as_view(), name='genres_update'),
    re_path(r'^genres/(?P<pk>\d+)/delete/$', views.GenresDelete.as_view(), name='genres_delete'),
    re_path(r'^books/$', views.BooksListView.as_view(), name='books'),
    re_path(r'^books/(?P<pk>\d+)$', views.BooksDetailView.as_view(), name='books-detail'),
    re_path(r'^books/create/$', views.BooksCreate.as_view(), name='books_create'),
    re_path(r'^books/(?P<pk>\d+)/update/$', views.BooksUpdate.as_view(), name='books_update'),
    re_path(r'^books/(?P<pk>\d+)/delete/$', views.BooksDelete.as_view(), name='books_delete'),
]
