from django.shortcuts import render
from .models import Authors, Genres, Books
from django.views import generic
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

def index(request):
    num_authors = Authors.objects.all().count()
    num_books = Books.objects.all().count()
    num_genres = Genres.objects.count()
    return render(
        request,
        'index.html',
        context={'num_authors': num_authors, 'num_books': num_books, 'num_genres': num_genres},
    )

class AuthorsListView(generic.ListView):
    model = Authors
    context_object_name = 'authors_list'
    template_name = 'authors.html'

class AuthorsDetailView(generic.DetailView):
    model = Authors
    context_object_name = 'author_data'
    template_name = 'authors_detail.html'

class AuthorsCreate(CreateView):
    model = Authors
    fields = '__all__'
    template_name = 'authors_form.html'

class AuthorsUpdate(UpdateView):
    model = Authors
    fields = '__all__'
    template_name = 'authors_form.html'

class AuthorsDelete(DeleteView):
    model = Authors
    success_url = reverse_lazy('authors')
    template_name = 'authors_delete.html'

class BooksListView(generic.ListView):
    model = Books
    context_object_name = 'books_list'
    template_name = 'books.html'

class BooksDetailView(generic.DetailView):
    model = Books
    context_object_name = 'book_data'
    template_name = 'books_detail.html'

class BooksCreate(CreateView):
    model = Books
    fields = '__all__'
    template_name = 'books_form.html'

class BooksUpdate(UpdateView):
    model = Books
    fields = '__all__'
    template_name = 'books_form.html'

class BooksDelete(DeleteView):
    model = Books
    success_url = reverse_lazy('books')
    template_name = 'books_delete.html'

class GenresListView(generic.ListView):
    model = Genres
    context_object_name = 'genres_list'
    template_name = 'genres.html'

class GenresDetailView(generic.DetailView):
    model = Genres
    context_object_name = 'genre_data'
    template_name = 'genres_detail.html'

class GenresCreate(CreateView):
    model = Genres
    fields = '__all__'
    template_name = 'genres_form.html'

class GenresUpdate(UpdateView):
    model = Genres
    fields = '__all__'
    template_name = 'genres_form.html'

class GenresDelete(DeleteView):
    model = Genres
    success_url = reverse_lazy('genres')
    template_name = 'genres_delete.html'
