from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Authors',
            fields=[
                ('id', models.IntegerField(primary_key=True, serialize=False, verbose_name='id')),
                ('name', models.CharField(max_length=120, verbose_name='имя автора')),
            ],
        ),
        migrations.CreateModel(
            name='Genres',
            fields=[
                ('id', models.IntegerField(primary_key=True, serialize=False, verbose_name='id')),
                ('name', models.CharField(max_length=120, verbose_name='название жанра')),
            ],
        ),
        migrations.CreateModel(
            name='Books',
            fields=[
                ('id', models.IntegerField(primary_key=True, serialize=False, verbose_name='id')),
                ('title', models.CharField(max_length=120, verbose_name='название книги')),
                ('year', models.IntegerField(verbose_name='год выпуска')),
                ('author', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='literature.authors')),
                ('genre', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='literature.genres')),
            ],
        ),
    ]
