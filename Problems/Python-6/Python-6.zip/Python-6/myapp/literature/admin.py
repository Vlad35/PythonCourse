from django.contrib import admin
from .models import Authors, Genres, Books

class AuthorModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
    list_display_links = ['id']
    search_fields = ['name']
    list_editable = ['name']

    class Meta:
        model = Authors

class BookModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'year', 'author', 'genre']
    list_display_links = ['id']
    search_fields = ['title', 'year', 'author__name', 'genre__name']
    list_editable = ['title', 'year', 'author', 'genre']

    class Meta:
        model = Books

class GenreModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
    list_display_links = ['id']
    search_fields = ['name']
    list_editable = ['name']

    class Meta:
        model = Genres

admin.site.register(Authors, AuthorModelAdmin)
admin.site.register(Books, BookModelAdmin)
admin.site.register(Genres, GenreModelAdmin)
