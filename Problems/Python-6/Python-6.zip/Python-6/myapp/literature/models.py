from django.db import models
from django.urls import reverse

# Create your models here.
class Authors(models.Model):
    id = models.AutoField(primary_key=True, verbose_name='id')
    name = models.CharField(max_length=120, blank=False, null=False, verbose_name='ФИО')

    def __str__(self):
        return str(self.id) + " " + str(self.name)

    def get_absolute_url(self):
        return reverse('authors-detail', args=[str(self.id)])

    def get_name(self):
        return "authors"

    class Meta:
        verbose_name = 'Автор'
        verbose_name_plural = 'Авторы'
        db_table = 'authors'
        ordering = ["id"]


class Genres(models.Model):
    id = models.AutoField(primary_key=True, verbose_name='id')
    name = models.CharField(max_length=120, blank=False, null=False, verbose_name='Название жанра')

    def __str__(self):
        return str(self.id) + " " + str(self.name)

    def get_absolute_url(self):
        return reverse('genres-detail', args=[str(self.id)])

    def get_name(self):
        return "genres"

    class Meta:
        verbose_name = 'Жанр'
        verbose_name_plural = 'Жанры'
        db_table = 'genres'
        ordering = ["id"]


class Books(models.Model):
    id = models.AutoField(primary_key=True, verbose_name='id')
    title = models.CharField(max_length=120, blank=False, null=False, verbose_name='Название книги')
    year = models.IntegerField(blank=False, null=False, verbose_name='Год издания')
    author = models.ForeignKey('Authors', on_delete=models.CASCADE, verbose_name='Автор')
    genre = models.ForeignKey('Genres', on_delete=models.CASCADE, verbose_name='Жанр')

    def __str__(self):
        return str(self.id) + " " + str(self.title) + " " + str(self.year) + " " + str(self.author) + " " + str(self.genre)

    def get_absolute_url(self):
        return reverse('books-detail', args=[str(self.id)])

    def get_name(self):
        return "books"

    class Meta:
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'
        db_table = 'books'
        ordering = ["id"]
