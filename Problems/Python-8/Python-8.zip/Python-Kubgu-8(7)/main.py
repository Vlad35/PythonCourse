import xmltodict

fin = open('Data.osm', 'r', encoding='utf-8')
dct = xmltodict.parse(fin.read())
police = set()

for node in dct['osm']['node']:
    if 'tag' in node and isinstance(node['tag'], list):
        address = None
        for tag in node['tag']:
            if tag['@k'] == "addr:street":
                address = tag['@v']
        if address:
            police.add(address)

sorted_police = sorted(police)

print("Количество:")
print(len(sorted_police))

for address in sorted_police:
    print(f"Адрес: {address}")
