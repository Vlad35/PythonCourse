import xmltodict

fin = open('Data.osm', 'r', encoding='utf-8')
dct = xmltodict.parse(fin.read())
police_stations = []

for node in dct['osm']['node']:
    if 'tag' in node and isinstance(node['tag'], list):
        for tag in node['tag']:
            if tag['@k'] == "amenity" and tag['@v'] == "police":
                police_stations.append(node)

police_stations.sort(key=lambda x: x['@id'])  # Сортируем по адресу (id)

for station in police_stations:
    address = ''
    if 'tag' in station and isinstance(station['tag'], list):
        for tag in station['tag']:
            if tag['@k'] == 'addr:street':
                address += tag['@v'] + ', '
            if tag['@k'] == 'addr:housenumber':
                address += tag['@v']
        print(address)
