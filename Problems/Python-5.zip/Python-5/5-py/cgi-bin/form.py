#!/usr/bin/env python3
import cgi
import html
import sqlite3

conn = sqlite3.connect('Literature.db')
cur = conn.cursor()

cur.execute("""CREATE TABLE IF NOT EXISTS Books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    year INTEGER,
    author_id INTEGER,
    genre_id INTEGER
    ); 
""")
conn.commit()

cur.execute("""CREATE TABLE IF NOT EXISTS Authors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
    ); 
""")
conn.commit()

cur.execute("""CREATE TABLE IF NOT EXISTS Genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
    ); 
""")
conn.commit()

form = cgi.FieldStorage()

book_data = [0]*4
book_data[0] = form.getfirst("TEXT_03", "не задано")
book_data[1] = form.getfirst("TEXT_04", "не задано")
book_data[2] = form.getfirst("TEXT_05", "не задано")
book_data[3] = form.getfirst("TEXT_06", "не задано")

author_data = [0]
author_data[0] = form.getfirst("TEXT_01", "не задано")

genre_data = [0]
genre_data[0] = form.getfirst("TEXT_02", "не задано")

cur.execute("""INSERT INTO Books (title, year, author_id, genre_id) VALUES (?, ?, ?, ?);""", book_data)
cur.execute("""INSERT INTO Authors (name) VALUES (?);""", author_data)
cur.execute("""INSERT INTO Genres (name) VALUES (?);""", genre_data)

print(genre_data)
print(book_data)
print(author_data)

# Экранирование специальных символов HTML
book_data = tuple(html.escape(data) for data in book_data)
author_data = tuple(html.escape(data) for data in author_data)
genre_data = tuple(html.escape(data) for data in genre_data)

print("Content-type: text/html\n")
print("""<!DOCTYPE HTML>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Обработка данных форм</title>
        </head>
        <body>""")

print("<h1>Обработка данных форм!</h1>")
print("<p>Book Data: {}</p>".format(book_data))
print("<p>Author Data: {}</p>".format(author_data))
print("<p>Genre Data: {}</p>".format(genre_data))

conn.commit()

print("""</body>
        </html>""")
