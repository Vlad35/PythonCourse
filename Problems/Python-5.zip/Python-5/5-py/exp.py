import sqlite3
import xml.etree.ElementTree as ET
conn = sqlite3.connect('Literature.db')
cursor = conn.cursor()


name1 = ET.Element('authors_xml')
doc1 = ET.ElementTree(name1)
authors_xml = ET.SubElement(name1, 'authors')
cursor.execute('SELECT * FROM Authors')
authors = cursor.fetchall()
for author in authors:
    client_xml = ET.SubElement(authors_xml, 'author', id = str(author[0]),
                               name=str(author[1]))
with open ('authors.xml', 'wb') as outFile1:
    doc1.write(outFile1)


name2 = ET.Element('books_xml')
doc2 = ET.ElementTree(name2)
books_xml = ET.SubElement(name2, 'books')
cursor.execute('SELECT * FROM Books')
books = cursor.fetchall()
for book in books:
    insurance_agent_xml = ET.SubElement(books_xml, 'book', id=str(book[0]),
                                        title=str(book[1]),
                                        year=str(book[2]),
                                        author_id=str(book[3]),
                                        genre_id=str(book[4]))
with open ('books.xml', 'wb') as outFile2:
    doc2.write(outFile2)


name3 = ET.Element('genres_xml')
doc3 = ET.ElementTree(name3)
genres_xml = ET.SubElement(name3, 'genres')
cursor.execute('SELECT * FROM Genres')
genres = cursor.fetchall()
for genre in genres:
    curr_insurance_xml = ET.SubElement(genres_xml, 'genre', id=str(genre[0]),
                                       name=str(genre[1]))
with open ('genre.xml', 'wb') as outFile3:
    doc3.write(outFile3)