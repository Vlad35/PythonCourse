import sqlite3
import xml.etree.ElementTree as ET

conn = sqlite3.connect('Literature.db')
cursor = conn.cursor()


cursor.execute("""CREATE TABLE IF NOT EXISTS Books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    year INTEGER,
    author_id INTEGER,
    genre_id INTEGER
    ); 
""")
conn.commit()

cursor.execute("""CREATE TABLE IF NOT EXISTS Authors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
    ); 
""")
conn.commit()

cursor.execute("""CREATE TABLE IF NOT EXISTS Genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
    ); 
""")
conn.commit()

doc = ET.parse('my_xml.xml')
root = doc.getroot()
authors,books,genres = [], [], []

for child, i in zip(root, range(3)):
    for child2 in child:
        if i == 0:
            authors.append(child2.attrib)
        elif i == 1:
            books.append(child2.attrib)
        elif i == 2:
            genres.append(child2.attrib)


for author in authors:
    name = author['name']
    cursor.execute("""INSERT INTO Authors(name) VALUES (?);""", (name,))

for book in books:
    title = book['title']
    year = int(book['year'])
    author_id = int(book['author_id'])
    genre_id = int(book['genre_id'])
    cursor.execute("""INSERT INTO Books(title, year, author_id, genre_id) VALUES (?, ?, ?, ?);""",
                   (title, year, author_id, genre_id))

for genre in genres:
    name = genre['name']
    cursor.execute("""INSERT INTO Genres(name) VALUES (?);""",
                   (name,))


conn.commit()
conn.close()